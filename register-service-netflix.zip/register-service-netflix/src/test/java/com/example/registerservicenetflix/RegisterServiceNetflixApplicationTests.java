package com.example.registerservicenetflix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterServiceNetflixApplicationTests {

	@Test
	void contextLoads() {
	}

}
