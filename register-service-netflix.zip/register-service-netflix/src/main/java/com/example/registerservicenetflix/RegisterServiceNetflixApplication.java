package com.example.registerservicenetflix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterServiceNetflixApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegisterServiceNetflixApplication.class, args);
	}

}
